import React, {useRef} from "react";
import GrandChild from "./GrandChild"

function child(props){
    const resultRef = useRef();

function handleClearAll(){

    alert("i can only Change the status inside the childs component")
    resultRef.current.value = ""
}    

return (
    <div>
        <h4> child component</h4><br/><br/>
        <label ref={resultRef}>Result: {props.resultValue}</label><br/><br/>
        <input type="submit" value="ClearAll" onClick={handleClearAll}/><br/><br/>
        <hr/>
        <GrandChild {...props}/>
    </div>
);
}
export default child;