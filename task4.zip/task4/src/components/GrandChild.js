import React from "react";

function GrandChild(props) {
    function handleClearAll () {
        alert("sorry: cant see the elements inside the childs component")
}



return(
    <div>

<h5> GrandChild component</h5><br/><br/>
<label>user Email:{props.objectToChild.userEmail} - user Role:{props.objectToChild.UserRole}</label><br/><br/>
<ul>
    {props.arrayOfObjectsToChild.map(Element =>(
        <li key={Element.id}>{Element.id}: course: {Element.course} - trainer: {Element.trainer}</li> 
     ))}
</ul><br/>
<input type="submit" value="clear All" onClick={handleClearAll}/>
</div>
);    
}

export default GrandChild;