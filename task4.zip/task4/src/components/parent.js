import React,{useState,UseRef, useRef} from "react";
import  Child   from "./child"

function parent(){
const[Result , setRrsult] =useState("")
const inputRef = useRef();

//object
const[myObjectData , setMyObjectData] = useState({userEmail:"mike@gmail.com" , userRole:"Admin"});
//arry of  objects
const [myArryData, setMyArryData] = useState([
    {id: 1, course: "React.js", trainer:"chris"},
    {id:2 , course: "vue", trainer:"Alex"}
] );
return (
   
    <div>
    <div>
    <h3>parent component </h3><br/>
    <input type="text" ref={inputRef} onChange={event => setRrsult(event.target.value)}/><br/><br/>
    <hr/>
    <Child
    ResultValue ={Result}
    arrayObjectsToChild = {myArryData}
    ObjectsToChild= {myObjectData}
    />
    </div>
    </div>
    );
}