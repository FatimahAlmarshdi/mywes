import './App.css';
import { useState, useRef} from 'react'; 
function App() {
  const [serverUrl, setServerUrl] = useState('') 
  const [requestBody, setRequestBody] = useState("") 
  const resultRef = useRef(); 
   
 
  async function handleRequest(){ 
   const requestObject = {
    query : `
    query{
      queryName{
        queryStudent
        queryCourse
        queryTrainer
  
      }
      mutation {
        updateUserStatus(strEmail:"Chris@gmail.com",blnIsActive:true")
       }
    `
   }
    
     await fetch(serverUrl, {
       method: 'POST', 
       body: JSON.stringify(requestObject),
       headers: {
         'Content-Type': 'application/json'
       }
      })
    .then(res => { 
         if (res.status !== 200 && res.status !== 201) {
           resultRef.current.value = "Failed to request the server"; 
          }
       return res.text(); 
       }) 
       .then(response => {

         resultRef.current.value = JSON.stringify(response.data.getAallStudentCourseTrainer[0]) 
       })
         .catch(err => {
            resultRef.current.value = err; 
         });
        }

  async function handlesubmit(){
    resultRef.current.value = ""
    handleRequest()
  }
  async function handleClear() {
    resultRef.current.value = ""
  }
  var example =`
  query{
    queryName{
      queryfield1
      queryfield2
      queryfield3

    }
    
    mutation {
      queryName(strEmail:"Chris@gmail.com",blnIsActive:true")
     }

  }`
async function handleFileChange(e){

    resultRef.current.value =""
    var userData ={}
    var userFiles =[]

    userData =
    {
      strType:"profileimage",
      intTotalFiles: e.currentTarget.files.lenghth
    }

    Array.from(e.currentTarget.files).forEach(File => {
      userFiles.push(File)
    })
    const formData = new formData();
    formData.append("userData",JSON.stringify(userData))
    Array.from(userFiles).forEach(file => {
      formData.append("userFiles",file);
    })
    
  let headers = new headers();
  headers.append('Accept','application/json')
  headers.append('Accept-control-Allow-Origin','*')
   const res = await fetch("http://localhost:4000/uploadfiles", {
    method:'POST',
    enctype:"multipart/form-data",
    headers: headers,
    body: formData
  });
  const json =await res.json();

  resultRef.current.value = JSON.stringify(json.response)


  }

    return ( 
      <div className="App"> 
       <textarea 
       onChange={ event=>setServerUrl(event.target.value)}
       placeholder="http://localhost:4000/graphql" rows={1}  cols={75}
       /><br/><br/> 
       
       <textarea 
       onChange= {event => setRequestBody(event.target.value)} 
       placeholder ={example} rows={12} cols={75}
       /><br/> 
       <button type="button" onClick= {handlesubmit} >submit</button><br/><hr/><br/>
       <input type="file" multiple onChange={handleFileChange} /> <br/><br/><hr/>
       <button type="button" onClick= {handleClear} >Clear</button> <br/>
        
        <textarea 
        ref={resultRef} placeholder="Result" rows={15} cols={75} 
        />
        </div> 
        ); 
    }


export default App;
