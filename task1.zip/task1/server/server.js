const express = require('express')
const app = express();
const PORT = 4000

const cors = require('cors')

const { request, response } = require('express');

app.listen(PORT, ()=>{
    console.log(`Server is listening on port ${PORT}`)})


app.use(cors())

app.get("/", (req,res) =>{

return res.send(`wecom <br/> strName = ${req.param("strName")} <br/>  dtmDOB =${ req.param("dtmDOB") } <br/> strEmail = ${ req.param("strEmail") } <br/>strPassword == ${ req.param("strPassword")} <br/>`)
})
