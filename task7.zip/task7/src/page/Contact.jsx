import React from 'react'

function Contact() {
  return (
    <div className="  items-center justify-center py-2">
      <h1 className="text-4xl bg-blue-600 text-white text-center">
        Contact us
      </h1>
      <h2 className='ml-4'>Contact us section</h2>
    </div>
  );
}

export default Contact