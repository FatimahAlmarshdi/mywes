import './App.css';
import { useState, useRef} from 'react'; 
function App() { 
  const [serverUrl, setServerUrl] = useState('') 
  const [requestBody, setRequestBody] = useState("") 
  const resultRef = useRef(); 
   
 
  async function handleRequest(){ 
    const requestObject ={query: requestBody} 
   
    
     await fetch(serverUrl, {
       method: 'POST', 
       body: JSON.stringify(requestObject),
       headers: {
         'Content-Type': 'application/json'
       }
      })
      .then(res => { 
         if (res.status !== 200 && res.status !== 201) {
           resultRef.current.value = "Failed to request the server"; 
           }
       return res.json(); 
       }) 
       .then(response => {
         resultRef.current.value = JSON.stringify(response.data.getAallStudentCourseTrainer[0]) 
       })
         .catch(err => {
            resultRef.current.value = err; 
         });
        }

  async function handlesubmit(){
    resultRef.current.value = ""
    handleRequest()
  }
  async function handleClear() {
    resultRef.current.value = ""
  }
  var example =`
  query{
    queryfield1
    queryfield2
    queryfield3
  }
    mutation {
      updateUserStatus(strEmail:"Chris@gmail.com",blnIsActive:true")
     }

  }`
  

    return ( 
      <div className="App"> 
       <textarea 
       onChange={ event=>setServerUrl(event.target.value)}
       placeholder="http://localhost:4000/graphql" rows={1}  cols={75}
       /><br/><br/> 
       
       <textarea 
       onChange= {event => setRequestBody(event.target.value)} 
       placeholder ={example} rows={12} cols={75}
       /><br/> 
       <button type="button" onclick= {handlesubmit} >submit</button><br/><hr/><br/>
       <button type="button" onclick= {handleClear} >Clear</button> <br/>
        
        <textarea 
        ref={resultRef} placeholder="Result" rows={15} cols={75} 
        />
        </div> 
        ); 
    }


export default App;
